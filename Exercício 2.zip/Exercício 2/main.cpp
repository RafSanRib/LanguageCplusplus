#include <iostream>

using namespace std;

int main()
{
 float celsius;
 float fahrenheint;
 cout <<"digita a temperatura em fahrenheint: ";
 cin >>fahrenheint ;
 celsius= (fahrenheint - 32) /1,8 ;
 cout <<"a temperatura em celsius e "<< celsius ;
}
