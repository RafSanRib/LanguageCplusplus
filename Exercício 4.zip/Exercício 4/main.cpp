#include <iostream>

using namespace std;

int main()
{
 string produto1;
 string produto2;
 string produto3;
 float valor1;
 float valor2;
 float valor3;
 int quantidade1;
 int quantidade2;
 int quantidade3;
 float total;

 cout <<"digite o nome do primeiro produto: ";
 cin >> produto1;
 cout <<"digite o nome do segudo produto: ";
 cin >> produto2;
 cout <<"digite o nome do terceiro produto: ";
 cin >> produto3;

 cout <<"digite o valor do primeiro produto: ";
 cin >> valor1;
 cout <<"digite o valor do segudo produto: ";
 cin >> valor2;
 cout <<"digite o valor do terceiro produto: ";
 cin >> valor3;

 cout <<"digite a quantidade do primeiro produto: ";
 cin >> quantidade1;
 cout <<"digite o quantidade do segudo produto: ";
 cin >> quantidade2;
 cout <<"digite o quantidade do terceiro produto: ";
 cin >> quantidade3;

total= (valor1 * quantidade1) + (valor2 * quantidade2) + (valor3 * quantidade3);
cout <<"o valor da sua compra e de: " <<total;
}
