#include <iostream>

using namespace std;

int main()
{
 float kilometros;
 float preco;
 float gasto;

 cout<<"digite a kilometragem percorrida: ";
 cin>>kilometros;
 cout<<"digite o preco do combustivel: ";
 cin>>preco;

 gasto = (kilometros / 8) * preco;
 cout<<"o valor gasto por kilometragem rodados foi de: R$"<<gasto;
}
