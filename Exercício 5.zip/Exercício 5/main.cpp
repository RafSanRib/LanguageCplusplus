#include <iostream>

using namespace std;

int main()
{
 float valor1;
 float valor2;
 float valor3;
 float valor4;
 float valor5;
 float valor6;
 float valor7;
 float total;
 cout<<"digite primeiro valor: ";
 cin>>valor1;
 cout<<"digite segundo valor: ";
 cin>>valor2;
 cout<<"digite terceiro valor: ";
 cin>>valor3;
 cout<<"digite quarto valor: ";
 cin>>valor4;
 cout<<"digite quinto valor: ";
 cin>>valor5;
 cout<<"digite sexto valor: ";
 cin>>valor6;
 cout<<"digite setimo valor: ";
 cin>>valor7;
 total= (valor1 + valor2 + valor3 + valor4 + valor5 + valor6 + valor7) / 7;
 cout<<"a sua media e de: "<<total;
}
