#include <iostream>

using namespace std;

int main()
{
 float valor1;
 float valor2;
 float soma;
 float divisao;
 float subtracao;
 float multiplicacao;
 cout <<"digite um valor: ";
 cin >> valor1;
 cout <<"digite um valor: ";
 cin >> valor2;
 soma=valor1+valor2;
 divisao=valor1/valor2;
 subtracao=valor1-valor2;
 multiplicacao=valor1*valor2;
 cout <<"o seu resultado da soma " <<soma;
 cout <<"o seu resultado da divisao " <<divisao;
 cout <<"o seu resultado da subtracao " <<subtracao;
 cout <<"o seu resultado da soma multiplicacao" <<multiplicacao;
}
