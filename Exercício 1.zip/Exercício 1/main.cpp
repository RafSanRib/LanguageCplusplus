#include <iostream>

using namespace std;

int main()
{
 string nome;
 string cidade;
 cout <<"inserir o seu nome ";
 cin >> nome ;
 cout <<"digite sua cidade ";
 cin >> cidade;
 cout <<"seu nome e " <<nome;
 cout <<" sua cidade e " <<cidade;
}
